<img src="{{url('frontend/assets/img/lynx.jpg') }}" alt="" style="width:128px;">
