<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5">
        <div class="d-flex flex-column text-center mb-5 pt-5">
            <h4 class="text-secondary mb-3">Nos Posts</h4>
        </div>
       <!-- Detail Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">

                <div class="col-lg-8">

                    <div class="mb-5">
                        <h6 class="text-primary mb-3"><?php echo e($post->created_at); ?></h6>
                        <h1 class="mb-5"><?php echo e($post->title); ?></h1>
                        <img class="img-fluid rounded w-100 mb-4" height="300" width="150" src="<?php echo e(Storage::url($post->image)); ?>" alt="Image">
                        <p class="text-justify"><?php echo e($post->description); ?></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Detail End -->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ExpertComptableSite\resources\views/blogs/show.blade.php ENDPATH**/ ?>