<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                <div class="space-y-8 divide-y divide-gray-200 w-1/2 mt-10">
                    <form method="POST" action="" enctype="multipart/form-data">

                      <div class="sm:col-span-6">
                        <label for="title" class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white"> Titre: </label>
                        <div class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white">
                          <?php echo e($contact->name); ?>

                        </div>
                        <label for="title" class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white"> Email: </label>
                        <div class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white">
                          <?php echo e($contact->email); ?>

                        </div>
                        <label for="title" class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white"> Telephone: </label>
                        <div class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white">
                          <?php echo e($contact->number); ?>

                        </div>
                        <label for="title" class="px-6 py-4 text-sm font-medium text-gray whitespace-nowrap dark:text-white"> Description: </label>
                        <div class="mt-1 px-6 text-sm text-gray font-medium  dark:text-white ">
                          <?php echo e($contact->description); ?>

                        </div>
                      </div>

                      </div>

                    </form>
                  </div>
            </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\ExpertComptableSite\resources\views/admin/contacts/show.blade.php ENDPATH**/ ?>