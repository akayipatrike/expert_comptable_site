<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Blog Start -->
    <style>
        .card-img-top{
            object-fit: cover;
            height: 300px;
        }
    </style>
    <div class="container pt-5">
        <div class="d-flex flex-column text-center mb-5 pt-5">
            <h4 class="text-secondary mb-3">Nos Posts</h4>
            <h1 class="display-4 m-0"><span class="text-primary">Nos Differents </span> Posts Sur Notre Blog</h1>
        </div>
        <div class="row pb-3">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mb-4 d-flex">
                <div class="card border-0 mb-2">
                    <img class="card-img-top"  src="<?php echo e(Storage::url($post->image)); ?>" alt="">
                    <div class="card-body bg-light p-4 d-flex flex-col">
                        <h4 class="card-title text-truncate"><?php echo e($post->title); ?></h4>
                        <div class="d-flex mb-3">
                            <small class="mr-2"><i class="fa fa-user text-muted"></i> <?php echo e($post->created_at->format('d M Y')); ?></small>
                        </div>
                        <p><?php echo e(Str::limit($post->description, 120)); ?></p>
                        <div class="mt-auto">
                            <a class="font-weight-bold" href="<?php echo e(route ('blogs.show', $post->id)); ?>">voir plus</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-center">
                <?php echo $posts->links(); ?>


            </div>
        </div>
    </div>
    <!-- Blog End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ExpertComptableSite\resources\views/blogs/index.blade.php ENDPATH**/ ?>